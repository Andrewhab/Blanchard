// dropdown
const params = {
    btnClassName: "nav-bottom__item-btn",
    activeClassName: "is-active",
    disabledClassName: "is-disabled"
}

function onDisable(evt) {
    if (evt.target.classList.contains(params.disabledClassName)) {
        evt.target.classList.remove(params.disabledClassName, params.activeClassName);
        evt.target.removeEventListener("animationend", onDisable);
    }
}

function setMenuListener() {
    document.body.addEventListener("click", (evt) => {
        const activeElements = document.querySelectorAll(`.${params.activeClassName}`);

        if (activeElements.length && !evt.target.closest(`.${params.activeClassName}`)) {
            activeElements.forEach((current) => {
                if (current.classList.contains(params.btnClassName)) {
                    current.classList.remove(params.activeClassName);
                } else {
                    current.classList.add(params.disabledClassName);
                }
            });
        }

        if (evt.target.closest(`.${params.btnClassName}`)) {
            const btn = evt.target.closest(`.${params.btnClassName}`);
            const path = btn.dataset.path;
            const drop = document.querySelector(`[data-target="${path}"]`);

            btn.classList.toggle(params.activeClassName);

            if (!drop.classList.contains(params.activeClassName)) {
                drop.classList.add(params.activeClassName);
                drop.addEventListener("animationend", onDisable);
            } else {
                drop.classList.add(params.disabledClassName);
            }
        }
    });
}

setMenuListener();

// hero

const swiper = new Swiper('.swiper-container', {
    allowTouchMove: false,
    loop: true,
    effect: 'fade',
    speed: 10000,
    autoplay: {
        delay: 10000
    }
});

// choices
const defaultSelect = () => {
    const element = document.querySelector('.gallery-select');
    const choices = new Choices(element, {
        searchEnabled: false,
    });
};

defaultSelect();


// tabs

$(function() {
    $(
        "#accordion-france, #accordion-germany, #accordion-italy, #accordion-russia, #accordion-belgium"
    ).accordion({
        icons: {
            header: false,
            activeHeader: false,
        },
        collapsible: true,
        heightStyle: "content",
        active: 0,
    });
});

function tabs(btnTab, btnTabActive, content, contentActive) {
    document.querySelectorAll(btnTab).forEach(function(tabsBtn) {
        tabsBtn.addEventListener("click", function(event) {
            event.preventDefault();
            const path = event.currentTarget.dataset.path;
            document.querySelectorAll(btnTab).forEach((element) => {
                element.classList.remove(btnTabActive);
            });
            tabsBtn.classList.add(btnTabActive);
            document.querySelectorAll(content).forEach(function(tabContent) {
                tabContent.classList.remove(contentActive);
            });
            document
                .querySelector(`[data-target="${path}"]`)
                .classList.add(contentActive);

            let width = $(window).width();
            if (width <= 768) {
                $(tabsBtn).on("click", function() {
                    $("html,body").animate({
                            scrollTop: $(`[data-target="${path}"]`).offset().top + "px",
                        },
                        2000
                    );
                });
            }
        });
    });
}
tabs(
    ".catalog__list-btn",
    "catalog-active",
    ".catalog__content",
    "catalog__content-active"
);
tabs(
    ".accordion-france-link",
    "block__link-active",
    ".france",
    "card-visible"
);
tabs(
    ".accordion-germany-link",
    "block__link-active",
    ".germany",
    "card-visible"
);
tabs(
    ".accordion-italy-link",
    "block__link-active",
    ".italian",
    "card-visible"
);
tabs(".accordion-rus-link", "block__link-active", ".russian", "card-visible");
tabs(
    ".accordion-belg-link",
    "block__link-active",
    ".belgium",
    "card-visible"
);


// events

document.addEventListener('DOMContentLoaded', function() {
    const eventsButton = document.querySelector('.all-events-btn');

    eventsButton.addEventListener('click', function() {
        document.querySelectorAll('.events__item').forEach(function(event) {
            event.style.display = "flex";
        });

        document.querySelectorAll('.events__item').forEach(function(item) {
            item.classList.add('events__item__margin');
        });

        document.querySelector('.all-events-btn').classList.add('all-events-btn__hidden');
    });
});

// mobile-event

document.addEventListener('DOMContentLoaded', function() {
    const pageWidth = window.matchMedia('(max-width: 700px)');

    function createMobileSwiper() {
        document.querySelector('.events__swiper-container').classList.add('events__mobile-swiper');
        document.querySelector('.events__swiper-container').classList.remove('swiper-no-swiping');

        document.querySelector('.events__list').classList.add('swiper-wrapper');

        document.querySelectorAll('.events__item:nth-child(1n + 3)').forEach(item => {
            item.style.display = 'block';
        });

        document.querySelectorAll('.events__item').forEach(item => {
            item.classList.add('swiper-slide');
        });

        const mobileSwiper = new Swiper('.events__swiper-container', {
            direction: 'horizontal',
            // loop: true,
            spaceBetween: 20,

            pagination: {
                el: '.swiper-pagination-custom',
                bulletClass: 'swiper-pagination-bullet-custom',
                bulletActiveClass: 'swiper-pagination-bullet-active-custom',
                clickable: 'true',
            },
        });
    }

    if (pageWidth.matches) {
        createMobileSwiper();
    }

    pageWidth.addEventListener('change', event => {
        if (!event.matches) {
            document.querySelector('.events__swiper-container').classList.remove('events__mobile-swiper', 'swiper-container-initialized', 'swiper-container-horizontal');
            document.querySelector('.events__swiper-container').classList.add('swiper-no-swiping');

            document.querySelector('.events__list').classList.remove('swiper-wrapper');

            document.querySelectorAll('.events__item:nth-child(1n + 3)').forEach(item => {
                item.style.display = '';
            });

            document.querySelectorAll('.events__item').forEach(item => {
                item.classList.remove('swiper-slide', 'swiper-slide-active');
                item.style.width = '';
                item.style.marginRight = '';
            });

            if (document.querySelector('.all-events-btn').classList.contains('all-events-btn__hidden')) {
                document.querySelector('.all-events-btn').classList.remove('all-events-btn__hidden');
            }
        } else {
            createMobileSwiper();
        }
    });
});

// editions
(() => {
    const checkBtn = document.querySelector('.js-check-heading');

    checkBtn.addEventListener('click', function() {
        this.classList.toggle('is-active');
    });
})();

// editions-mobile
document.addEventListener('DOMContentLoaded', function() {
    const spoilerBtn = document.querySelector('.mobile-spoiler__heading');
    const spoilerList = document.querySelector('.mobile-spoiler__categories-list');
    const items = document.querySelectorAll('.categories-list__item');

    items.forEach(item => {
        if (item.querySelector('input').checked) {
            item.classList.add('categories-list__item__clicked');
            itemToggling(item, 'show');
        }

        item.querySelector('input').addEventListener('click', function() {
            if (!item.querySelector('input').checked) {
                item.classList.remove('categories-list__item__clicked');
                if (!spoilerList.classList.contains('mobile-spoiler__categories-list__active')) {
                    itemToggling(item, 'hide');
                }
            } else {
                item.classList.add('categories-list__item__clicked');
            }
        });
    });

    spoilerBtn.addEventListener('click', spoilerToggling);

    function spoilerToggling() {
        if (!spoilerList.classList.contains('mobile-spoiler__categories-list__active')) {
            spoilerBtn.classList.add('mobile-spoiler__heading__active');

            spoilerList.classList.add('mobile-spoiler__categories-list__active');

            items.forEach(item => {
                itemToggling(item, 'show');
            });
        } else {
            spoilerBtn.classList.remove('mobile-spoiler__heading__active');

            spoilerList.classList.remove('mobile-spoiler__categories-list__active');

            items.forEach(item => {
                if (item.querySelector('input').checked) {
                    item.classList.add('categories-list__item__clicked');
                    itemToggling(item, 'show');
                } else {
                    item.classList.remove('categories-list__item__clicked');
                    itemToggling(item, 'hide');
                }
            });
        }
    }

    function itemToggling(item, action) {
        if (action === 'show') {
            item.classList.add('categories-list__item__active');
            setTimeout(function() {
                item.classList.add('categories-list__item__animated');
            }, 100);
        } else {
            item.classList.remove('categories-list__item__animated');
            setTimeout(function() {
                item.classList.remove('categories-list__item__active');
            }, 300);
        }
    }
});

// project tooltip

tippy('#first-tooltip', {
    content: 'Пример современных тенденций - современная методология разработки',
    interactive: true,
});

tippy('#second-tooltip', {
    content: 'Приятно, граждане, наблюдать, как сделанные на базе аналитики выводы вызывают у вас эмоции',
    interactive: true,
});

tippy('#third-tooltip', {
    content: 'В стремлении повысить качество',
    interactive: true,
});

//validate-form

var selector = document.querySelector("input[type='tel']");
var im = new Inputmask("+7 (999)-999-99-99");

im.mask(selector);

new JustValidate(".contacts-form", {
    rules: {
        name: {
            required: true,
            minLength: 2,
            maxLength: 20
        },
        tel: {
            required: true,
            function: (name, value) => {
                const phone = selector.input.unmaskedvalue()
                return Number(phone) && phone.length === 10
            }
        }
    },
    colorWrong: '#FF5C00',
    messages: {
        name: {
            required: 'Введите Ваше имя',
        },
        tel: {
            required: 'Введите Ваш номер телефона'
        },
    },
});


// map

document.addEventListener('DOMContentLoaded', () => {
    let myMap;

    function initDesktop() {
        myMap = new ymaps.Map('map', {
            center: [55.75991743174908, 37.63745011920072],
            zoom: 14,
        });

        var myPlacemark = new ymaps.Placemark([55.75846306898368, 37.601079499999905], {}, {
            iconLayout: 'default#image',
            iconImageHref: 'img/placemark.png',
            iconImageSize: [20, 20]
        });

        myMap.geoObjects.add(myPlacemark);
    }

    function init1440() {
        myMap = new ymaps.Map('map', {
            center: [55.75991743174908, 37.62745011920072],
            zoom: 14,
        });

        var myPlacemark = new ymaps.Placemark([55.75846306898368, 37.601079499999905], {}, {
            iconLayout: 'default#image',
            iconImageHref: 'img/placemark.png',
            iconImageSize: [20, 20]
        });

        myMap.geoObjects.add(myPlacemark);
    }

    function initTablet() {
        myMap = new ymaps.Map('map', {
            center: [55.75991743174908, 37.61745011920072],
            zoom: 14,
        });

        var myPlacemark = new ymaps.Placemark([55.75846306898368, 37.601079499999905], {}, {
            iconLayout: 'default#image',
            iconImageHref: 'img/placemark.png',
            iconImageSize: [20, 20]
        });

        myMap.geoObjects.add(myPlacemark);
    }

    function init768() {
        myMap = new ymaps.Map('map', {
            center: [55.75991743174908, 37.60745011920072],
            zoom: 14,
        });

        var myPlacemark = new ymaps.Placemark([55.75846306898368, 37.601079499999905], {}, {
            iconLayout: 'default#image',
            iconImageHref: 'img/placemark.png',
            iconImageSize: [20, 20]
        });

        myMap.geoObjects.add(myPlacemark);
    }

    function initMobile() {
        myMap = new ymaps.Map('map', {
            center: [55.75991743174908, 37.60745011920072],
            zoom: 14,
        });

        var myPlacemark = new ymaps.Placemark([55.75846306898368, 37.601079499999905], {}, {
            iconLayout: 'default#image',
            iconImageHref: 'img/placemark.png',
            iconImageSize: [20, 20]
        });

        myMap.geoObjects.add(myPlacemark);
    }

    if (window.matchMedia("(max-width: 470px)").matches) {
        ymaps.ready(initMobile);
    } else if (window.matchMedia("(max-width: 1023px)").matches) {
        ymaps.ready(init768);
    } else if (window.matchMedia("(max-width: 1439px)").matches) {
        ymaps.ready(initTablet);
    } else if (window.matchMedia("(max-width: 1919px)").matches) {
        ymaps.ready(init1440);
    } else if (window.matchMedia("(min-width: 1920px)").matches) {
        ymaps.ready(initDesktop);
    }

    const widthDesktop = window.matchMedia('(min-width: 1920px)');
    const widthSmallDesktop = window.matchMedia('(max-width: 1919px)');
    const widthTablet = window.matchMedia('(max-width: 1439px)');
    const widthBigMobile = window.matchMedia('(max-width: 1023px)');
    const widthMobile = window.matchMedia('(max-width: 470px)');

    widthMobile.addEventListener('change', e => {
        if (e.matches) {
            myMap.setCenter([55.75846306898368, 37.601079499999905], 14, {});
        }
    });

    widthBigMobile.addEventListener('change', e => {
        if (e.matches) {
            myMap.setCenter([55.75991743174908, 37.60745011920072], 14, {});
        }
    });

    widthTablet.addEventListener('change', e => {
        if (e.matches) {
            myMap.setCenter([55.75991743174908, 37.61745011920072], 14, {});
        }
    });

    widthSmallDesktop.addEventListener('change', e => {
        if (e.matches) {
            myMap.setCenter([55.75991743174908, 37.62745011920072], 14, {});
        }
    });

    widthDesktop.addEventListener('change', e => {
        if (e.matches) {
            myMap.setCenter([55.75991743174908, 37.63745011920072], 14, {});
        }
    });
});

// burger

const burger = document.querySelector(".header__burger-menu"),
    burgerMenu = document.querySelector(".header__menu"),
    menuLink = document.querySelectorAll(".header__nav-link"),
    body = document.body;
burger.addEventListener("click", () => {
        burger.classList.toggle("burger-menu_active"),
            burgerMenu.classList.toggle("menu_active"),
            body.classList.toggle("lock")
    }),
    menuLink.forEach(e => {
        e.addEventListener("click", () => {
            burger.classList.remove("burger-menu_active"),
                burgerMenu.classList.remove("menu_active"),
                body.classList.remove("lock")
        })
    });

// search

btnSearch = document.querySelector(".header__search-tablet-btn"),
    formSearch = document.querySelector(".header__search-tablet"),
    closeSearch = document.querySelector(".tablet-search__close");
btnSearch.addEventListener("click", e => {
        e.preventDefault(), formSearch.classList.add("form-open")
    }),
    closeSearch.addEventListener("click", e => {
        e.preventDefault(), formSearch.classList.remove("form-open")
    });
